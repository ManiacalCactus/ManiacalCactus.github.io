// Package Game allows to types of gameplay, one the allows a user to graphically
// play the game and the other which outsources control of the game to an instance of
// snakeAI

package Game

import (
	"GoSnake/LinearAlgebra"
	"GoSnake/SnakeAI"
	"fmt"
	"math/rand"
	"time"

	"github.com/faiface/pixel"
	"github.com/faiface/pixel/imdraw"
	"github.com/faiface/pixel/pixelgl"
	"golang.org/x/image/colornames"
)

//Constants below are for both types of gameplay
const maxTime = 500

const showWindow = false

const fieldWidth = 30
const fieldHeight = 30

const windowWidth = float64(700)
const windowHeight = float64(700)

const delay = 50 * time.Millisecond

//Variables below are for user controlled gameplay and are modified statically
var headX = 15
var headY = 15

var direction = "u"
var previousDirection = "u"

var score = 0

var field = make([][]Space, fieldHeight)

var pointY int
var pointX int

type Instance struct {
	AI                SnakeAI.Instance
	Score             int
	headX             int
	headY             int
	time              int
	field             [][]Space
	direction         string
	previousDirection string
}

//Run runs a full length game of snake as a pixelgl window controlled by the user
func run() {
	cfg := pixelgl.WindowConfig{
		Title:  "GoSnake",
		Bounds: pixel.R(0, 0, windowWidth, windowHeight),
		VSync:  true,
	}
	win, err := pixelgl.NewWindow(cfg)
	if err != nil {
		panic(err)
	}

	win.Clear(colornames.Skyblue)

	imd := imdraw.New(nil)

	//Eindow loop
	for !win.Closed() {
		//Game loop
		imd.Clear()
		field[randomNumber(fieldHeight)][randomNumber(fieldWidth)].variety = "point"
		for true {
			//Move head of snake
			if previousDirection == direction {
				switch direction {
				case "l":
					headX--
				case "r":
					headX++
				case "d":
					headY--
				case "u":
					headY++
				}
			}

			//Get user keyboard input
			getInput(win)

			//Check if dead
			if headX >= fieldWidth || headX < 0 || headY >= fieldHeight || headY < 0 {
				break
			}

			//Check if snake ate a point
			if field[headY][headX].variety == "point" {
				addPoint()
				score++
			} else if field[headY][headX].variety == "snake" && direction == previousDirection {
				//Check if dead by running into itself
				break
			}
			previousDirection = direction

			//Set the spot the head is on to disappear after a set number of cycles depending
			//on the score
			field[headY][headX].cyclesLeft = score
			field[headY][headX].variety = "snake"

			//Draw the field
			for r := range field {
				for c := range field[r] {
					if field[r][c].variety == "point" {
						imd.Color = colornames.Red
					} else if field[r][c].variety == "snake" {
						imd.Color = colornames.Green
						field[r][c].cyclesLeft--
						if field[r][c].cyclesLeft <= 0 {
							field[r][c].variety = "free"
						}
					} else {
						imd.Color = colornames.Black
					}
					imd.Push(pixel.V(float64(c)*(windowWidth/float64(fieldWidth)), float64(r)*(windowHeight/float64(fieldHeight))))
					imd.Push(pixel.V(float64(c+1)*(windowWidth/float64(fieldWidth)), float64(r+1)*(windowHeight/float64(fieldHeight))))
					imd.Rectangle(0)
				}
			}

			//Update the window and draw
			win.Update()
			imd.Draw(win)

			//delay to slow down the game
			time.Sleep(delay)

		}
		gameOver(score)
		return
	}
}

//Run hidden runs a full length game of snake without creating a window or
//delaying.  It only allows input by a snakeAI Instance
func (game *Instance) RunHidden() {
	//Set all the initial values of the game instance's variables
	game.field = make([][]Space, fieldHeight)
	game.headX = 15
	game.headY = 15
	game.time = 0
	game.Score = 3
	game.direction = "u"
	game.previousDirection = "u"

	//Create the fiel matrix
	for r := range game.field {
		game.field[r] = make([]Space, fieldWidth)
		for c := range game.field[r] {
			game.field[r][c] = Space{variety: "free"}
		}
	}

	//Place a point at a random spot
	game.field[randomNumber(fieldHeight)][randomNumber(fieldWidth)].variety = "point"

	//Game loop runs until the AI loses
	for true {
		//Progress the game clock
		game.time = game.time + 1

		//Destroy any AI which passes the maximum time in order to prevent it from
		//learning to live infinitely by moving in a continuous loop
		if game.time > maxTime {
			game.Score = -1
			break
		}

		//Move the head of the snake
		if game.previousDirection == game.direction {
			switch game.direction {
			case "l":
				game.headX--
			case "r":
				game.headX++
			case "d":
				game.headY--
			case "u":
				game.headY++
			}
		}

		//Get input based on the game
		getAIInput(game, game.AI)

		//Check if dead by wall
		if game.headX >= fieldWidth-1 || game.headX <= 0 || game.headY >= fieldHeight-1 || game.headY <= 0 {
			break
		}

		//Check if the snake at a point
		if game.field[game.headY][game.headX].variety == "point" {
			addPointOnInstance(game)
			game.Score++
		} else if game.field[game.headY][game.headX].variety == "snake" {
			//Check if the snake died by running into itself
			break
		}

		game.previousDirection = game.direction

		//Set the point at the snakes head to disappear after score number of cycles
		game.field[game.headY][game.headX].cyclesLeft = game.Score
		game.field[game.headY][game.headX].variety = "snake"

		//Count down all snake spaces on the game field
		for r := range game.field {
			for c := range game.field[r] {
				if game.field[r][c].variety == "point" {
				} else if game.field[r][c].variety == "snake" {
					game.field[r][c].cyclesLeft--
					if game.field[r][c].cyclesLeft <= 0 {
						game.field[r][c].variety = "free"
					}
				}
			}
		}

	}
	return
}

//GetFinalScore returns the final score for use by other classes that don't have
//access to score directly
func (g Instance) GetFinalScore() int {
	return g.Score
}

//GetFinalScore returns the final time for use by other classes that don't have
//access to time directly
func (g Instance) GetFinalTime() int {
	return g.time
}

//getInput gets keyboard input from the user and changes the static variable
//direction based on that input.  It also adds a point randomly on the map by
//hitting space
func getInput(win *pixelgl.Window) {
	if win.Pressed(pixelgl.KeyLeft) && direction != "r" {
		direction = "l"
	} else if win.Pressed(pixelgl.KeyRight) && direction != "l" {
		direction = "r"
	} else if win.Pressed(pixelgl.KeyDown) && direction != "u" {
		direction = "d"
	} else if win.Pressed(pixelgl.KeyUp) && direction != "d" {
		direction = "u"
	}

	if win.Pressed(pixelgl.KeySpace) {
		addPoint()
	}
	time.Sleep(time.Millisecond)
}

//getAIInput gets an output vector based on an input vector comprised of: the
//distance from the head of the snake to the nearest threat up, down, left,
//and right, and the distance to the point on the field in the X axis and the
//Y axis
func getAIInput(game *Instance, instance SnakeAI.Instance) {

	//Check to make sure that the snake hasn't already lost
	if game.headX > fieldWidth-1 || game.headX < 0 || game.headY > fieldHeight-1 || game.headY < 0 {
		game.Score = score
		return
	}

	// Construct the input vector
	inputs := make([][]float64, 1)
	inputs[0] = make([]float64, 6)

	//Starting at the position of the head and traversing to the end of the board
	//in a given direction, find the distance to the closest threat space in that
	//direction, wall or snake.  Place those values into the input vector
	//0:Up, 1:Down, 2:Left, 3:Right
	for threatUp := 0; game.headY+threatUp < fieldHeight; threatUp++ {
		if game.field[game.headY+threatUp][game.headX].variety == "snake" {
			inputs[0][0] = float64(threatUp)
			break
		} else {
			inputs[0][0] = float64(fieldHeight - game.headY)
		}
	}
	for threatDown := 0; game.headY-threatDown >= 0; threatDown++ {
		if game.field[game.headY-threatDown][game.headX].variety == "snake" {
			inputs[0][1] = float64(threatDown)
			break
		} else {
			inputs[0][1] = float64(game.headY)
		}
	}
	for threatLeft := 0; game.headX-threatLeft >= 0; threatLeft++ {
		if game.field[game.headY][game.headX-threatLeft].variety == "snake" {
			inputs[0][2] = float64(threatLeft)
			break
		} else {
			inputs[0][2] = float64(game.headX)
		}
	}
	for threatRight := 0; game.headX+threatRight < fieldWidth; threatRight++ {
		if game.field[game.headY][game.headX+threatRight].variety == "snake" {
			inputs[0][3] = float64(threatRight)
			break
		} else {
			inputs[0][3] = float64(fieldWidth - game.headX)
		}
	}

	//Place the X and Y distance from the head to the point into the input vector
	//at indexes 4 and 5 respectively
	inputs[0][4] = float64(pointX - game.headX)
	inputs[0][5] = float64(pointY - game.headY)

	//Construct the vector wrapper and input the weights
	inputVector := LinearAlgebra.Matrix{}
	inputVector.SetWeights(inputs)

	//Compute the output vector based on the input vector with the given instance
	//of snakeAI
	outputVector := instance.Compute(inputVector)

	//find the maximum value of the output vector
	maxVal := float64(-1)
	maxInd := 0
	for i := 0; i < len(outputVector.Weights[0]); i++ {
		if outputVector.Weights[0][i] > maxVal {
			maxInd = i
			maxVal = outputVector.Weights[0][i]
		}
	}

	//Move based on that value 0:Up, 1:Down, 2:Left, 3:Right
	switch maxInd {
	case 0:
		game.direction = "u"
	case 1:
		game.direction = "d"
	case 2:
		game.direction = "l"
	case 3:
		game.direction = "r"
	}
}

//gameOver prints the score for a user controlled game
func gameOver(score int) {
	fmt.Println("", score)
}

//addPointOnInstance places a point randomly for an instance of game, it also
//stores where it places the point in randY and randX
func addPointOnInstance(game *Instance) {
	randY := randomNumber(fieldHeight)
	randX := randomNumber(fieldWidth)
	for game.field[randY][randX].variety != "free" {
		randY = randomNumber(fieldHeight)
		randX = randomNumber(fieldWidth)
	}
	game.field[randY][randX].variety = "point"
	pointY = randY
	pointX = randX
}

//addPoint places a point and marks its position for a user controlled game
func addPoint() {
	randY := randomNumber(fieldHeight)
	randX := randomNumber(fieldWidth)
	for field[randY][randX].variety != "free" {
		randY = randomNumber(fieldHeight)
		randX = randomNumber(fieldWidth)
	}
	field[randY][randX].variety = "point"
	pointY = randY
	pointX = randX
}

//randomNumber returns a number less than the input number
func randomNumber(num int) int {
	result := int(rand.Int31n(int32(num)))
	return result

}

//runUserControl runs a user controlled game
func runUserControl() {
	for r := range field {
		field[r] = make([]Space, fieldWidth)
		for c := range field[r] {
			field[r][c] = Space{variety: "free"}
		}
	}
	pixelgl.Run(run)
}

//Space holds two values, its variety as a string: "free, snake, point" and the
//amount of time it has before expiring if it is a snake space
type Space struct {
	variety    string
	cyclesLeft int
}
