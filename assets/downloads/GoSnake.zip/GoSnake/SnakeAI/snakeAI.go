//Package SnakeAI acts as a wrapper for a NeuralNetwork, significantly
//simplifying its operation
package SnakeAI

import (
	"GoSnake/LinearAlgebra"
	"GoSnake/NeuralNetwork"
)

//Type Instance holds an instrance of NeuralNetwork
type Instance struct {
	network NeuralNetwork.NetworkInstance
}

//Compute computes the output of a given input acting on the network n
func (n Instance) Compute(input LinearAlgebra.Matrix) LinearAlgebra.Matrix {
	output, _ := n.network.Compute(input)
	return output
}

//Instantiate creates and randomizes a network of sizes laysizes
func (n *Instance) Instantiate(layerSizes []int) {
	n.network.Initialize(layerSizes)
	n.network.Randomize()
}

//CopyOf returns a copy of an instance in order to avoid issues with passing by
//pointer
func (n Instance) CopyOf() Instance {
	copy := Instance{}
	copy.network = n.network.CopyOf()
	return copy
}

//Mutate mutates the entirety of the neural network by rnadom numbers generated
//with an average value of 0 and standard deviation of deviation
func (n *Instance) Mutate(deviation float64) {
	n.network.Mutate(deviation)
}

//Print prints the entire network's weights to the console
func (n Instance) Print() {
	n.network.Display()
}
