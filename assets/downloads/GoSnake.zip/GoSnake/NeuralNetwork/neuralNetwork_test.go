package NeuralNetwork

import (
	"GoSnake/LinearAlgebra"
	"fmt"
	"testing"
)

//TestNeuralNetwork tests the integral functions in package NeuralNetwork
func TestNeuralNetwork(t *testing.T) {
	//Create and initialize a NeuralNetwork with layers sizes 1, 2, 3, 4
	n := NetworkInstance{}
	layers := []int{1, 2, 3, 4}
	n.Initialize(layers)
	fmt.Println(len(n.Matrices))
	n.Display()

	//Create an input vector and initialize it
	input := LinearAlgebra.Matrix{}
	input.Initialize()
	Weights := [][]float64{{0}}
	input.SetWeights(Weights)

	//Test the compute function of the network on the input vector
	n.Compute(input)
}
