//Package NeuralNetwork provides a structure to hold and operate on a set of
//matrices
package NeuralNetwork

import (
	"GoSnake/LinearAlgebra"
	"fmt"
)

//Struct NetworkInstance acts as a wrapper for an array of matrices
type NetworkInstance struct {
	Matrices []LinearAlgebra.Matrix
}

//Display prints the contents of matrices to the console
func (n NetworkInstance) Display() {
	for i := range n.Matrices {
		n.Matrices[i].Print()
		fmt.Println("")
	}
}

//Compute returns the result of each successive operation of the matrices on the
//next starting with the input and then returning the final output
func (n NetworkInstance) Compute(input LinearAlgebra.Matrix) (LinearAlgebra.Matrix, error) {
	//Run the first computation between the input and first matrix
	result, _ := LinearAlgebra.Multiply(input, n.Matrices[0])

	//Run the remaining computations on the rest of the array
	for i := 0; i < len(n.Matrices)-1; i++ {
		result, _ = LinearAlgebra.Multiply(result, n.Matrices[i+1])
		result.Sigmoid()
	}

	//Return the resulting vector
	return result, nil
}

//Initialize fills the matrices of a network instance with successive operation
//matrices of the correct sizes in order to perform successive operations based
//on the layer sizes provided as an array of integers
func (n *NetworkInstance) Initialize(layerSizes []int) {
	n.Matrices = make([]LinearAlgebra.Matrix, len(layerSizes)-1)
	for i := range n.Matrices {
		matrix := make([][]float64, layerSizes[i])
		for j := range matrix {
			matrix[j] = make([]float64, layerSizes[i+1])
		}
		n.Matrices[i].SetWeights(matrix)
	}
}

//Randomize iterates through each matrix in matrices and randomizes it
func (n *NetworkInstance) Randomize() {
	for matrix := range n.Matrices {
		n.Matrices[matrix].Randomize()
	}
}

//Mutate iterates through each matrix in matrices and mutates it based on
//deviation as the standard deviation
func (n *NetworkInstance) Mutate(deviation float64) {
	for matrix := range n.Matrices {
		n.Matrices[matrix].Mutate(deviation)
	}
}

//CopyOf creates a copy of NetworkInstance n and returns it in order to reduce
//issues caused by passing by pointer
func (n NetworkInstance) CopyOf() NetworkInstance {
	result := NetworkInstance{}
	result.Matrices = make([]LinearAlgebra.Matrix, len(n.Matrices))
	for m := range result.Matrices {
		result.Matrices[m] = n.Matrices[m].CopyOf()
	}
	return result
}
