//Package LinearAlgebra provides some of the most basics math and linear algebra
//to construct a neural network
package LinearAlgebra

import (
	"errors"
	"fmt"
	"math"
	"math/rand"
)

//Print prints out the content of a matrix to the console
func (m Matrix) Print() {
	for r, _ := range m.Weights {
		for c, _ := range m.Weights[r] {
			fmt.Printf("%2.2f \t", m.Weights[r][c])
		}
		fmt.Println("")
	}
}

//Multiply returns the result of a matrix multiplication operation between two
//matrices
func Multiply(matA Matrix, matB Matrix) (Matrix, error) {

	//Construct and initialize the result matrix to the correct size
	result := Matrix{Weights: make([][]float64, len(matA.Weights))}
	for i := range result.Weights {
		result.Weights[i] = make([]float64, len(matB.Weights[0]))
	}
	result.Initialize()

	//Return an error if the matrices are of incompatible sizes to perform
	//multiplication
	if len(matA.Weights[0]) != len(matB.Weights) {
		return Matrix{make([][]float64, 0)}, errors.New("Width of Weights A must be equal to height of Weights B")
	}

	//Perform the actual matrix multiplication on the matrices
	for r := range result.Weights {
		for c := range result.Weights[r] {
			sum := float64(0)
			for i := 0; i < len(matA.Weights[0]); i++ {
				sum += matA.Weights[r][i] * matB.Weights[i][c]
			}
			result.Weights[r][c] = sum
		}
	}
	return result, nil
}

//Type matrix is a wrapper for a 2d matrix of floats
type Matrix struct {
	Weights [][]float64
}

//Initialize fills matrix mat with 0s
func (mat *Matrix) Initialize() {
	for r := 0; r < len(mat.Weights); r++ {
		for c := 0; c < len(mat.Weights[r]); c++ {
			mat.Weights[r][c] = float64(0)
		}
	}
}

//SetWeights is a setter function for the matrix wrapper
func (mat *Matrix) SetWeights(w [][]float64) {
	mat.Weights = w
}

//Sigmoid mutates the matrix it is performed on so that each value is replaced
//by the result of a sigmoid function of the original.  It is intended to be
//used as an activation function
func (mat *Matrix) Sigmoid() {
	for r := 0; r < len(mat.Weights); r++ {
		for c := 0; c < len(mat.Weights[r]); c++ {
			mat.Weights[r][c] = float64(1) / (float64(1) + math.Pow(math.E, (-mat.Weights[r][c])))
		}
	}
}

//Randomize sets every item in a matrix to a random float between -5 and 5
func (mat *Matrix) Randomize() {
	for r := 0; r < len(mat.Weights); r++ {
		for c := 0; c < len(mat.Weights[r]); c++ {
			mat.Weights[r][c] = rand.Float64()*10 - 5
		}
	}
}

//Mutate multiplies each value of matrix mat by a random number calculated with
//an average value of zero and a standard distribution of deviation
func (mat *Matrix) Mutate(deviation float64) {
	for r := range mat.Weights {
		for c := range mat.Weights[r] {
			mat.Weights[r][c] = mat.Weights[r][c] + (deviation * rand.NormFloat64())
		}
	}
}

//CopyOf returns a copy of matrix mat in order to fix any issues with passing by
//pointer
func (mat Matrix) CopyOf() Matrix {
	copy := make([][]float64, len(mat.Weights))
	for r := range copy {
		copy[r] = make([]float64, len(mat.Weights[r]))
		for c := range copy[r] {
			copy[r][c] = mat.Weights[r][c]
		}
	}
	return Matrix{copy}

}
