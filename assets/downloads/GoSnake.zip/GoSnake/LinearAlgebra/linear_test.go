package LinearAlgebra

import (
	"fmt"
	"testing"
)

//TestLinear tests some of the most important functions of package LinearAlgebra
func TestLinear(t *testing.T) {
	//Construct two matrices of size 5x5
	testMatA := Matrix{Weights: make([][]float64, 5)}
	testMatB := Matrix{Weights: make([][]float64, 5)}
	for i := range testMatA.Weights {
		testMatA.Weights[i] = make([]float64, 5)
	}
	for i := range testMatB.Weights {
		testMatB.Weights[i] = make([]float64, 5)
	}

	//Initialize the two matrices
	testMatA.Initialize()

	//Print the size of the matrices
	fmt.Println(len(testMatA.Weights))
	fmt.Println(len(testMatA.Weights[0]))

	//Test the print function of matrix
	testMatA.Print()

	//Test the multiplication function of package LinearAlgebra
	result, _ := Multiply(testMatA, testMatB)

	//Print the result of the matrix multiplication
	result.Print()
}
