//Package main creates and evolves successive generations of snakeAI each built
//from the most fit of the previous generation
package main

import (
	"GoSnake/Game"
	"GoSnake/SnakeAI"
	"fmt"
)

const breedsPerGen = 25
const mutationRate = 2.0
const numGens = 150
const gamesPerInstance = 30
const pointTimeFitnessRatio = 25

//Network structure is built like this to encourage abstraction while still
//being short enough to avoid drawing out an computations too long to allow for
//a large number of generations and breeds per generation
var networkStructure = []int{6, 6, 6, 4, 4}

var generation = 0

func main() {
	//Initial construction of instances
	currentGen := make([]SnakeAI.Instance, breedsPerGen)
	for breed := range currentGen {
		currentGen[breed].Instantiate(networkStructure)
	}

	//Multi-generational loop
	for ; generation < numGens; generation++ {

		//Testing each of the breeds in the generation
		maxSumScore := 0
		maxScoreInd := 0
		for b := range currentGen {
			//Test each of the breeds a number of times
			sumScore := 0
			for g := 0; g < gamesPerInstance; g++ {
				//Run the game with moves calculated by the current breed in current gen
				game := Game.Instance{AI: currentGen[b]}
				game.RunHidden()

				//Calculate the fitness by multiplying the number of points acquired by
				//a constance to encourage this behavior.  Also add the total time to
				//encourage surviving as long as possible.
				sumScore += pointTimeFitnessRatio * game.GetFinalScore()
				sumScore += game.GetFinalTime()
			}
			fmt.Println("Fitness of generation ", generation, " breed ", b, " is ", sumScore)
			//Find the most fit breed from each generation
			if sumScore > maxSumScore {
				maxSumScore = sumScore
				maxScoreInd = b
			}
		}

		//End of generation analysis
		fmt.Printf("The max fitness in generation %d was %d over %d games \n", generation, maxSumScore, gamesPerInstance)
		fmt.Printf("Now mutating based on breed number %d \n", maxScoreInd)

		//Construct the next generation based on winner from previous
		winningBreed := currentGen[maxScoreInd]
		currentGen[0] = winningBreed.CopyOf()
		for i := 1; i < len(currentGen); i++ {
			currentGen[i] = winningBreed.CopyOf()
			currentGen[i].Mutate(mutationRate)
		}
	}
}
